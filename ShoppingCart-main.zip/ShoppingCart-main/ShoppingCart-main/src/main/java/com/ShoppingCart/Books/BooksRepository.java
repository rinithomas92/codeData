package com.ShoppingCart.Books;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface BooksRepository extends CrudRepository<Books, Integer>{
	
	@Query(value = "SELECT * FROM Books ORDER BY id", nativeQuery = true)
	List<Books> findAllBooks();

}
